let a = ' '
if (a) {
  console.log('Hello')
}
// {authState.errorMsg && (
//     <Toast
//       title="Important Alert!"
//       message={authState.errorMsg}
//       type="failure"
//       onClose={() => {
//         dispatch(setErrorMsg(''))
//       }}
//     />
//   )}

// useEffect(() => {
//   if (formik.touched.email && formik.errors.email) {
//     dispatch(setErrorMsg(formik.errors.email))
//   } else if (formik.touched.password && formik.errors.password) {
//     dispatch(setErrorMsg(formik.errors.password))
//   }
// }, [dispatch, formik.touched, formik.errors])

// useEffect(() => {
//   if (authState.errorMsg.includes('email is incorrect')) {
//     formik.setFieldError('email', authState.errorMsg)
//   } else if (authState.errorMsg.includes('password is incorrect')) {
//     formik.setFieldError('password', authState.errorMsg)
//   }
//   // eslint-disable-next-line react-hooks/exhaustive-deps
// }, [authState.errorMsg])

{
  /* {formik.touched.email && formik.errors.email && (
          <p className="form-error">{formik.errors.email}</p>
        )} */
}
