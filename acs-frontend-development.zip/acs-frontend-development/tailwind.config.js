/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#171C8F',
          200: '#EEEEFF',
          300: '#B3B5D9',
        },
        secondary: '#51B42E',
        gray: {
          DEFAULT: '#AFAFAF',
          100: '#F6F6F6',
          110: '#F5F5F5',
          120: '#F1F1F1',
          200: '#E1E1E1',
          350: '#C5C5C5',
          400: '#C2C2C2',
          500: '#AFAFAF',
          550: '#959595',
          590: '#7A7A7A',
          700: '#787878',
          900: '#555555',
          990: '#4B4B4B',
        },
        green: {
          DEFAULT: '#78BE20',
          200: '#E8FFE4',
          600: '#51B42E',
        },
        red: {
          DEFAULT: '#FF4646',
          200: '#FEECEC',
        },
      },
      fontFamily: {
        poppins: ['Poppins', 'sans-serif'],
      },
      fontSize: {
        13: '13px',
        15: '15px',
        17: '17px',
      },
    },
  },
  plugins: [],
}
