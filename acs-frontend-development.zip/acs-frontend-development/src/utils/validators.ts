import { REGEX } from '@/constants'

export const validateEmail = (value: string) => {
  if (!value || value === '') {
    return 'Email is required'
  }
  if (!REGEX.EMAIL.test(value)) {
    return 'Invalid email address'
  }
}

export const validatePassword = (value: string) => {
  if (!value || value === '') {
    return 'Password is required'
  }
  if (!REGEX.PASSWORD.test(value)) {
    return 'Create a secure password by ensuring it includes at least 1 special character (example: !@#$%&*), 1 number, and consists of a minimum of 8 total characters.'
  }
}

export const validateConfirmPassword = (pswd: string, cfPswd: string) => {
  if (pswd !== cfPswd) {
    return "Password doesn't match, please re-enter"
  }
}
