const ACCESS_TOKEN_KEY = 'auth'
const USER_PROFILE_KEY = 'user'

export const cacheAccessToken = (token: string) => {
  localStorage.setItem(ACCESS_TOKEN_KEY, token)
}

export const getAccessToken = () => {
  return localStorage.getItem(ACCESS_TOKEN_KEY)?.trim()
}

export const isSignedIn = () => {
  const token = getAccessToken()
  return !!token
}

export const cacheUser = (user: object) => {
  if (!user) return
  localStorage.setItem(USER_PROFILE_KEY, JSON.stringify(user))
}

export const getCachedUser = (): Record<string, any> | null => {
  try {
    const userStr = localStorage.getItem(USER_PROFILE_KEY)
    if (userStr) {
      return JSON.parse(userStr)
    }
    return null
  } catch (e) {
    return null
  }
}

export const clearUserCache = () => {
  localStorage.removeItem(ACCESS_TOKEN_KEY)
  localStorage.removeItem(USER_PROFILE_KEY)
}
