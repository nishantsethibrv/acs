export const isValidFileUrl = (url: string) =>
  /^(ftp|http|https):\/\/[^ "]+$/.test(url)

/**
 * @param {*} file - file URL or Local File instance
 */
export const downloadFile = async (
  fileUrl: string,
  fileName: string,
  onError?: () => void
) => {
  try {
    if (!isValidFileUrl(fileUrl)) {
      throw new Error('Invalid file url')
    }
    // file is URL
    const response = await fetch(fileUrl)
    if (!response.ok) {
      throw new Error(response.toString())
    }
    const blob = await response.blob()
    const url = URL.createObjectURL(blob)

    // Create a temporary anchor element
    const a = document.createElement('a')
    a.href = url
    a.download = fileName || 'download'
    // a.target='_blank';

    document.body.appendChild(a)
    a.click()
    // Remove the anchor from the document
    document.body.removeChild(a)

    URL.revokeObjectURL(url)
  } catch (e) {
    console.error(e)
    onError && onError()
  }
}
