// export const LOGIN_API = 'contractor/login'
export const LOGIN_API = 'api/v1/contractor/login'
export const LOGOUT_API = 'api/v1/contractor/logout'
export const FORGOT_PASSWORD_SEND_OTP_API = 'api/v1/contractor/forget-password'
export const FORGOT_PASSWORD_VERIFY_OTP_API =
  'api/v1/contractor/forgot-verify-otp'
export const FORGOT_PASSWORD_CREATE_NEW_PASSWORD_API =
  'api/v1/contractor/create-new-password'
export const DASHBOARD_API = 'api/v1/contractor/dashboard'
export const USER_PROFILE_API = 'api/v1/contractor/profile-details'
export const ASSIGNMENTS_BY_DATE = 'api/v1/contractor/get-assigments-by-date'
export const ASSIGNMENT_DETAILS = 'api/v1/contractor/get-assigments-details'
export const INVOICES_API = 'api/v1/contractor/timesheet/get-invoice'
