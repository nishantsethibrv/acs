export * from './apiPath'

export const REGEX = Object.freeze({
  EMAIL: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i,
  PASSWORD: /^(?=.*[!@#$%&*])(?=.*[0-9]).{8,}$/,
})

export const TOAST_INITIAL_DATA = {
  type: null,
  message: null,
}
