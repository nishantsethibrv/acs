/* eslint-disable @typescript-eslint/no-unused-vars */
import { createSlice } from '@reduxjs/toolkit'

type DashboardState = {
  isLoading: boolean
  errorMsg: string
  data: Record<string, any>
}

const initialState: DashboardState = {
  isLoading: false,
  errorMsg: '',
  data: {},
}

const dashboardSlice = createSlice({
  name: 'dashboard',
  initialState,
  reducers: {
    getDashboardData: (state) => {
      state.isLoading = true
    },
    getDashboardDataSuccess: (state, action) => {
      state.isLoading = false
      state.errorMsg = ''
      state.data = action.payload?.data
    },
    getDashboardDataFailure: (state, action) => {
      state.isLoading = false
      state.errorMsg = action.payload
    },
  },
})

export const {
  getDashboardData,
  getDashboardDataSuccess,
  getDashboardDataFailure,
} = dashboardSlice.actions

export default dashboardSlice.reducer
