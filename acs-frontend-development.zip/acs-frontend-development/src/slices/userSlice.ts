/* eslint-disable @typescript-eslint/no-unused-vars */
import { createSlice } from '@reduxjs/toolkit'

type UserState = {
  isLoading: boolean
  errorMsg: string
  profile: Record<string, any>
}

const initialState: UserState = {
  isLoading: false,
  errorMsg: '',
  profile: {},
}

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    getUserProfile: (state) => {
      state.isLoading = true
    },
    getUserProfileSuccess: (state, action) => {
      state.isLoading = false
      state.errorMsg = ''
      state.profile = action.payload?.data
    },
    getUserProfileFailure: (state, action) => {
      state.isLoading = false
      state.errorMsg = action.payload
    },
  },
})

export const { getUserProfile, getUserProfileSuccess, getUserProfileFailure } =
  userSlice.actions

export default userSlice.reducer
