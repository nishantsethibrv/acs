import authReducer from './authSlice'
import dashboardReducer from './dashboardSlice'
import userReducer from './userSlice'
import assignmentsReducer from './assignmentsSlice'
import invoicesReducer from './invoicesSlice'

export const rootReducer = {
  auth: authReducer,
  dashboard: dashboardReducer,
  user: userReducer,
  assignments: assignmentsReducer,
  invoices: invoicesReducer,
}
