/* eslint-disable @typescript-eslint/no-unused-vars */
import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  isSignedIn: false,
  isSignedOut: false,
  isLoading: false,
  errorMsg: '',
  toastData: {
    msg: '',
    type: '',
  },
  forgotPassword: {
    token: '',
    email: '',
    otpSent: false,
    optVerified: false,
    passwordCreated: false,
    resendOtpCount: 0,
  },
}

const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    startLogin: (state, _) => {
      state.isLoading = true
    },
    loginSuccess: (state) => {
      state.isLoading = false
      state.errorMsg = ''
      state.isSignedIn = true
    },
    loginFailure: (state, action) => {
      state.isLoading = false
      state.errorMsg = action.payload
    },
    forgotPasswordSendOTP: (state, action) => {
      state.isLoading = true
      state.forgotPassword.email = action.payload?.email
    },
    forgotPasswordSendOTPSuccess: (state, action) => {
      if (state.forgotPassword.otpSent) {
        state.forgotPassword.resendOtpCount =
          state.forgotPassword.resendOtpCount + 1
      }
      state.forgotPassword.token = action.payload?.data?.token
      state.forgotPassword.otpSent = true
      state.isLoading = false
    },
    forgotPasswordSendOTPFailure: (state, action) => {
      state.forgotPassword.otpSent = false
      state.isLoading = false
      state.errorMsg = action.payload
    },
    // forgotPasswordResendOTP: (state, _) => {
    //   state.isLoading = true
    // },
    // forgotPasswordResendOTPSuccess: (state, _) => {
    //   state.forgotPassword.otpSent = true
    //   state.isLoading = false
    // },
    // forgotPasswordResendOTPFailure: (state, action) => {
    //   state.forgotPassword.otpSent = false
    //   state.isLoading = false
    //   state.errorMsg = action.payload
    // },
    forgotPasswordVerifyOTP: (state, _) => {
      state.isLoading = true
    },
    forgotPasswordVerifyOTPSuccess: (state, _) => {
      state.forgotPassword.optVerified = true
      state.isLoading = false
    },
    forgotPasswordVerifyOTPFailure: (state, action) => {
      state.forgotPassword.optVerified = false
      state.isLoading = false
      state.errorMsg = action.payload
    },
    createNewPassword: (state, _) => {
      state.isLoading = true
    },
    createNewPasswordSuccess: (state, _) => {
      state.forgotPassword.passwordCreated = true
      state.isLoading = false
      state.toastData = {
        msg: 'Your password is updated successfully, try signing in with new password.',
        type: 'info',
      }
    },
    createNewPasswordFailure: (state, action) => {
      state.forgotPassword.passwordCreated = false
      state.isLoading = false
      state.errorMsg = action.payload
    },
    startLogout: (state) => {
      state.isLoading = true
    },
    logoutSuccess: (state) => {
      state.isLoading = false
      state.errorMsg = ''
      state.isSignedIn = false
      state.isSignedOut = true
    },
    logoutFailure: (state, action) => {
      state.isLoading = false
      state.errorMsg = action.payload
    },
    setErrorMsg: (state, action) => {
      state.errorMsg = action.payload
    },
    setToastData: (state, action) => {
      state.toastData = action.payload
    },
    resetState: (state) => {
      return {
        ...initialState,
        toastData: state.toastData,
      }
    },
  },
})

export const {
  startLogin,
  loginSuccess,
  loginFailure,
  setErrorMsg,
  forgotPasswordSendOTP,
  forgotPasswordSendOTPSuccess,
  forgotPasswordSendOTPFailure,
  forgotPasswordVerifyOTP,
  forgotPasswordVerifyOTPSuccess,
  forgotPasswordVerifyOTPFailure,
  createNewPassword,
  createNewPasswordSuccess,
  createNewPasswordFailure,
  startLogout,
  logoutSuccess,
  logoutFailure,
  resetState,
  setToastData,
} = authSlice.actions

export default authSlice.reducer
