/* eslint-disable @typescript-eslint/no-unused-vars */
import { createSlice } from '@reduxjs/toolkit'

type InvoicesState = {
  year: number
  allInvoices: {
    items: Record<string, any>[]
    isLoading: boolean
    errorMsg: string
  }
}

const initialState: InvoicesState = {
  year: new Date().getFullYear(),
  allInvoices: {
    items: [],
    isLoading: false,
    errorMsg: '',
  },
}

const invoicesSlice = createSlice({
  name: 'invoices',
  initialState,
  reducers: {
    getInvoices: (state) => {
      state.allInvoices.isLoading = true
      state.allInvoices.items = []
    },
    getInvoicesSuccess: (state, action) => {
      state.allInvoices = {
        isLoading: false,
        errorMsg: '',
        items: action.payload.data,
      }
    },
    getInvoicesFailure: (state, action) => {
      state.allInvoices.isLoading = false
      state.allInvoices.errorMsg = action.payload
    },
    setPrevYear: (state) => {
      state.year = state.year - 1
    },
    setNextYear: (state) => {
      state.year = state.year + 1
    },
  },
})

export const {
  getInvoices,
  getInvoicesSuccess,
  getInvoicesFailure,
  setPrevYear,
  setNextYear,
} = invoicesSlice.actions

export default invoicesSlice.reducer
