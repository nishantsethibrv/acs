/* eslint-disable @typescript-eslint/no-unused-vars */
import { createSlice } from '@reduxjs/toolkit'

type AssignmentsState = {
  monthDate: Date
  allAssignments: {
    items: []
    isLoading: boolean
    errorMsg: string
  }
  assignmentDetails: {
    isModalOpen: boolean
    data: Record<string, any> | null
    isLoading: boolean
    errorMsg: string
  }
}

const initialState: AssignmentsState = {
  monthDate: new Date(),
  allAssignments: {
    items: [],
    isLoading: false,
    errorMsg: '',
  },
  assignmentDetails: {
    data: null,
    isModalOpen: false,
    isLoading: false,
    errorMsg: '',
  },
}

const assignmentsSlice = createSlice({
  name: 'assignments',
  initialState,
  reducers: {
    getAllAssignments: (state) => {
      state.allAssignments.isLoading = true
    },
    getAllAssignmentsSuccess: (state, action) => {
      state.allAssignments = {
        isLoading: false,
        errorMsg: '',
        items: action.payload?.data,
      }
    },
    getAllAssignmentsFailure: (state, action) => {
      state.allAssignments.isLoading = false
      state.allAssignments.errorMsg = action.payload
    },
    setNextMonth: (state) => {
      state.monthDate = new Date(
        state.monthDate.getFullYear(),
        state.monthDate.getMonth() + 1,
        1
      )
    },
    setPrevMonth: (state) => {
      state.monthDate = new Date(
        state.monthDate.getFullYear(),
        state.monthDate.getMonth() - 1,
        1
      )
    },
    getAssignmentDetails: (state, _) => {
      state.assignmentDetails = {
        errorMsg: '',
        isModalOpen: true,
        isLoading: true,
        data: null,
      }
    },
    getAssignmentDetailsSuccess: (state, action) => {
      state.assignmentDetails.isLoading = false
      state.assignmentDetails.data = action.payload?.data
    },
    getAssignmentDetailsFailure: (state, action) => {
      state.assignmentDetails.isLoading = false
      state.assignmentDetails.errorMsg = action.payload
    },
    toggleAssignmentDetailsModal: (state) => {
      state.assignmentDetails.isModalOpen = !state.assignmentDetails.isModalOpen
    },
  },
})

export const {
  getAllAssignments,
  getAllAssignmentsSuccess,
  getAllAssignmentsFailure,
  setNextMonth,
  setPrevMonth,
  getAssignmentDetails,
  getAssignmentDetailsSuccess,
  getAssignmentDetailsFailure,
  toggleAssignmentDetailsModal,
} = assignmentsSlice.actions

export default assignmentsSlice.reducer
