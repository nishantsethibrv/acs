/// <reference types="vite-plugin-svgr/client" />
import { useEffect } from 'react'
import AppRoutes from './routes/AppRoutes'
import { useAppDispatch } from './hooks'
import { setupInterceptor } from './services/api'
import { isSignedIn } from './utils/cache'
import { getUserProfile } from './slices/userSlice'

function App() {
  const signedIn = isSignedIn()
  const dispatch = useAppDispatch()
  useEffect(() => {
    setupInterceptor()
    if (signedIn) {
      dispatch(getUserProfile())
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  return (
    <>
      <AppRoutes signedIn={signedIn} />
    </>
  )
}

export default App
