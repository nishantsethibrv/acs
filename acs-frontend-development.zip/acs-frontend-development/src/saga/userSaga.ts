import { call, all, put, takeLatest } from 'redux-saga/effects'
import { postRequest } from '@/services/api'
import { USER_PROFILE_API } from '@/constants'
import {
  getUserProfile,
  getUserProfileFailure,
  getUserProfileSuccess,
} from '@/slices/userSlice'
import { cacheUser, getCachedUser } from '@/utils/cache'

function* getUserProfileHandler(): Generator<any, any, any> {
  try {
    const cachedUser = getCachedUser()
    if (cachedUser) {
      yield put(getUserProfileSuccess({ data: cachedUser }))
    }
    const response: any = yield call(postRequest, USER_PROFILE_API)
    if (response && response.status === 200 && response.data?.code === 200) {
      cacheUser(response.data?.data)
      yield put(getUserProfileSuccess(response.data))
    } else {
      throw response?.data || response
    }
  } catch (e: any) {
    console.error('getUserProfileHandler', e)
    yield put(getUserProfileFailure(e?.message || 'Something went wrong'))
  }
}

export default function* () {
  yield all([takeLatest(getUserProfile.type, getUserProfileHandler)])
}
