import { call, all, put, takeLatest } from 'redux-saga/effects'
import { getRequest } from '@/services/api'
import {
  getDashboardData,
  getDashboardDataFailure,
  getDashboardDataSuccess,
} from '@/slices/dashboardSlice'
import { DASHBOARD_API } from '@/constants'

function* getDashboardDataHandler(): Generator<any, any, any> {
  try {
    const response: any = yield call(getRequest, DASHBOARD_API)
    if (response && response.status === 200 && response.data?.code === 200) {
      yield put(getDashboardDataSuccess(response.data))
    } else {
      throw response?.data || response
    }
  } catch (e: any) {
    console.error('getDashboardDataHandler', e)
    yield put(getDashboardDataFailure(e?.message || 'Something went wrong'))
  }
}

export default function* () {
  yield all([takeLatest(getDashboardData.type, getDashboardDataHandler)])
}
