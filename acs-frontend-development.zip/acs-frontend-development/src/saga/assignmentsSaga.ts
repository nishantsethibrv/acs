import { call, all, put, takeLatest, select } from 'redux-saga/effects'
import { postRequest } from '@/services/api'
import {
  getAllAssignments,
  getAllAssignmentsFailure,
  getAllAssignmentsSuccess,
  getAssignmentDetails,
  getAssignmentDetailsFailure,
  getAssignmentDetailsSuccess,
} from '@/slices/assignmentsSlice'
import { ASSIGNMENTS_BY_DATE, ASSIGNMENT_DETAILS } from '@/constants'
import { RootState } from '@/store'

function* getAllAssignmentsHandler(): Generator<any, any, any> {
  try {
    const monthYear: Date = yield select(
      (state: RootState) => state.assignments.monthDate
    )
    const response: any = yield call(postRequest, ASSIGNMENTS_BY_DATE, {
      data: {
        shift_month_year: monthYear.getMonthYearShort(),
      },
    })
    if (response && response.status === 200 && response.data?.code === 200) {
      yield put(getAllAssignmentsSuccess(response.data))
    } else {
      throw response?.data || response
    }
  } catch (e: any) {
    console.error('getAllAssignmentsHandler', e)
    yield put(getAllAssignmentsFailure(e?.message || 'Something went wrong'))
  }
}

function* getAssignmentDetailsHandler(action: any): Generator<any, any, any> {
  try {
    const { shiftId: shift_id } = action.payload ?? {}
    const response: any = yield call(postRequest, ASSIGNMENT_DETAILS, {
      data: {
        shift_id,
      },
    })
    if (response && response.status === 200 && response.data?.code === 200) {
      yield put(getAssignmentDetailsSuccess(response.data))
    } else {
      throw response?.data || response
    }
  } catch (e: any) {
    console.error('getAssignmentDetailsHandler', e)
    yield put(getAssignmentDetailsFailure(e?.message || 'Something went wrong'))
  }
}

export default function* () {
  yield all([
    takeLatest(getAllAssignments.type, getAllAssignmentsHandler),
    takeLatest(getAssignmentDetails.type, getAssignmentDetailsHandler),
  ])
}
