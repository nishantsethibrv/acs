import { call, all, put, takeLatest, select } from 'redux-saga/effects'
import { postRequest } from '@/services/api'
import {
  startLogin,
  loginSuccess,
  loginFailure,
  startLogout,
  logoutSuccess,
  logoutFailure,
  forgotPasswordSendOTPSuccess,
  forgotPasswordSendOTPFailure,
  forgotPasswordVerifyOTPSuccess,
  forgotPasswordVerifyOTPFailure,
  createNewPasswordSuccess,
  createNewPasswordFailure,
  forgotPasswordSendOTP,
  forgotPasswordVerifyOTP,
  createNewPassword,
} from '@/slices/authSlice'
import {
  FORGOT_PASSWORD_CREATE_NEW_PASSWORD_API,
  FORGOT_PASSWORD_SEND_OTP_API,
  FORGOT_PASSWORD_VERIFY_OTP_API,
  LOGIN_API,
  LOGOUT_API,
} from '@/constants'
import { cacheAccessToken, cacheUser, clearUserCache } from '@/utils/cache'
import { RootState } from '@/store'

// Generator<WhatYouYield, WhatYouReturn, WhatYouAccept>
function* loginHandler(action: any): Generator<any, any, any> {
  try {
    const data = action.payload ?? {}
    const response: any = yield call(postRequest, LOGIN_API, {
      data,
    })
    if (response && response.status === 200 && response.data?.code === 200) {
      cacheAccessToken(response.data?.data?.user?.api_token)
      cacheUser(response.data?.data?.user)
      yield put(loginSuccess(response.data))
    } else {
      throw response?.data || response
    }
  } catch (e: any) {
    console.error('loginHandler', e)
    yield put(loginFailure(e?.message || 'Something went wrong'))
  }
}

function* logoutHandler(): Generator<any, any, any> {
  try {
    const response: any = yield call(postRequest, LOGOUT_API)
    if (response && response.status === 200 && response.data?.code === 200) {
      clearUserCache()
      yield put(logoutSuccess(response.data))
    } else {
      if (response?.data?.message?.includes('token has expired')) {
        clearUserCache()
        yield put(logoutSuccess())
      } else {
        throw response?.data || response
      }
    }
  } catch (e: any) {
    console.error('logoutHandler', e)
    yield put(logoutFailure(e?.message || 'Something went wrong'))
  }
}

function* forgotPasswordSendOtpHandler(action: any): Generator<any, any, any> {
  try {
    const data = action.payload ?? {}
    const response: any = yield call(
      postRequest,
      FORGOT_PASSWORD_SEND_OTP_API,
      {
        data,
      }
    )
    if (response && response.status === 200 && response.data?.code === 200) {
      yield put(forgotPasswordSendOTPSuccess(response.data))
    } else {
      throw response?.data || response
    }
  } catch (e: any) {
    console.error('forgotPasswordSendOtpHandler', e)
    yield put(
      forgotPasswordSendOTPFailure(e?.message || 'Something went wrong')
    )
  }
}

function* forgotPasswordVerifyOtpHandler(
  action: any
): Generator<any, any, any> {
  try {
    const otp = action.payload?.otp
    const { email, token } = yield select(
      (state: RootState) => state.auth.forgotPassword
    )
    const response: any = yield call(
      postRequest,
      FORGOT_PASSWORD_VERIFY_OTP_API,
      {
        data: {
          otp,
          email,
        },
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    )
    if (response && response.status === 200 && response.data?.code === 200) {
      yield put(forgotPasswordVerifyOTPSuccess(response.data))
    } else {
      throw response?.data || response
    }
  } catch (e: any) {
    console.error('forgotPasswordVerifyOtpHandler', e)
    yield put(
      forgotPasswordVerifyOTPFailure(e?.message || 'Something went wrong')
    )
  }
}

function* createNewPasswordHandler(action: any): Generator<any, any, any> {
  try {
    const { newPassword: new_password, confirmPassword: confirm_password } =
      action.payload ?? {}
    const { email, token } = yield select(
      (state: RootState) => state.auth.forgotPassword
    )
    const response: any = yield call(
      postRequest,
      FORGOT_PASSWORD_CREATE_NEW_PASSWORD_API,
      {
        data: {
          email,
          new_password,
          confirm_password,
        },
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    )

    if (response && response.status === 200 && response.data?.code === 200) {
      yield put(createNewPasswordSuccess(response.data))
    } else {
      throw response?.data || response
    }
  } catch (e: any) {
    console.error('createNewPasswordHandler', e)
    yield put(createNewPasswordFailure(e?.message || 'Something went wrong'))
  }
}

export default function* () {
  yield all([
    takeLatest(startLogin.type, loginHandler),
    takeLatest(startLogout.type, logoutHandler),
    takeLatest(forgotPasswordSendOTP.type, forgotPasswordSendOtpHandler),
    takeLatest(forgotPasswordVerifyOTP.type, forgotPasswordVerifyOtpHandler),
    takeLatest(createNewPassword.type, createNewPasswordHandler),
  ])
}
