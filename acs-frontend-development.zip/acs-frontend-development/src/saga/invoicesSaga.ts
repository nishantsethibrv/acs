import { call, all, put, takeLatest, select } from 'redux-saga/effects'
import { postRequest } from '@/services/api'
import { RootState } from '@/store'
import {
  getInvoices,
  getInvoicesFailure,
  getInvoicesSuccess,
} from '@/slices/invoicesSlice'
import { INVOICES_API } from '@/constants'

function* getInvoicesHandler(): Generator<any, any, any> {
  try {
    const year: number = yield select((state: RootState) => state.invoices.year)
    const response: any = yield call(postRequest, INVOICES_API, {
      data: {
        year,
      },
    })
    if (response && response.status === 200 && response.data?.code === 200) {
      yield put(getInvoicesSuccess(response.data))
    } else {
      throw response?.data || response
    }
  } catch (e: any) {
    console.error('getInvoicesHandler', e)
    yield put(getInvoicesFailure(e?.message || 'Something went wrong'))
  }
}

export default function* () {
  yield all([takeLatest(getInvoices.type, getInvoicesHandler)])
}
