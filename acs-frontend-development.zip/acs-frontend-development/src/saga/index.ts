import { all } from 'redux-saga/effects'
import authSaga from './authSaga'
import dashboardSaga from './dashboardSaga'
import userSaga from './userSaga'
import assignmentsSaga from './assignmentsSaga'
import invoicesSaga from './invoicesSaga'

export function* rootSaga() {
  yield all([
    authSaga(),
    dashboardSaga(),
    userSaga(),
    assignmentsSaga(),
    invoicesSaga(),
  ])
}
