import { Navigate, useLocation } from 'react-router-dom'
import { isSignedIn } from '@/utils/cache'

type RequireAuthProps = {
  children: React.ReactNode
}

export default function RequireAuth({ children }: RequireAuthProps) {
  const signedIn = isSignedIn()
  const location = useLocation()

  if (!signedIn) {
    return <Navigate to="/login" state={location} />
  }
  return children
}
