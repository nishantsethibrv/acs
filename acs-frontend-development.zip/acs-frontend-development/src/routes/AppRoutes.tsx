import { Suspense, lazy } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
const Login = lazy(() => import('@/pages/auth/Login'))
const ForgotPassword = lazy(() => import('@/pages/auth/ForgotPassword'))
const DefaultLayout = lazy(() => import('@/components/layout/DefaultLayout'))
const Dashboard = lazy(() => import('@/pages/Dashboard'))
const RequireAuth = lazy(() => import('./RequireAuth'))
const Assignments = lazy(() => import('@/pages/Assignments'))
const Invoices = lazy(() => import('@/pages/Invoices'))
const PageNotFound = lazy(() => import('@/pages/PageNotFound'))
import Loader from '@/components/Loader'

const AppRoutes = ({ signedIn }: { signedIn: boolean }) => {
  return (
    <Routes>
      <Route
        path="/"
        element={
          <Suspense fallback={<Loader center />}>
            <RequireAuth>
              <DefaultLayout />
            </RequireAuth>
          </Suspense>
        }
      >
        <Route
          index
          element={
            <Suspense fallback={<Loader center />}>
              <Dashboard />
            </Suspense>
          }
        />
        <Route
          path="assignments"
          element={
            <Suspense fallback={<Loader center />}>
              <Assignments />
            </Suspense>
          }
        />
        <Route
          path="invoices"
          element={
            <Suspense fallback={<Loader center />}>
              <Invoices />
            </Suspense>
          }
        />
      </Route>
      <Route
        path="/login"
        element={
          <Suspense fallback={<Loader center />}>
            {signedIn ? <Navigate to="/" replace /> : <Login />}
          </Suspense>
        }
      />
      <Route
        path="/forgot-password"
        element={
          <Suspense fallback={<Loader center />}>
            {signedIn ? <Navigate to="/" replace /> : <ForgotPassword />}
          </Suspense>
        }
      />
      <Route
        path="*"
        element={
          <Suspense fallback={<Loader center />}>
            <PageNotFound />
          </Suspense>
        }
      />
    </Routes>
  )
}

export default AppRoutes
