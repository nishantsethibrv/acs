import { Outlet } from 'react-router-dom'
import Sidebar from '../Sidebar'
import Header from '../Header'
import Loader from '../Loader'
import { useAppSelector } from '@/hooks'

const DefaultLayout = () => {
  const isLoadingUser = useAppSelector((state) => state.user.isLoading)
  return (
    <div className="relative ms-[140px] min-h-screen">
      <Sidebar />
      <div className="w-full max-w-[1320px] mx-auto px-5 pt-9 pb-2">
        {isLoadingUser ? (
          <Loader center />
        ) : (
          <>
            <Header />
            <Outlet />
          </>
        )}
      </div>
    </div>
  )
}

export default DefaultLayout
