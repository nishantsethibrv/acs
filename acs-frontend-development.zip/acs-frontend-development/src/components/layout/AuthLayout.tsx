import Toast from '../Toast'
import { LoaderModal } from '../Loader'
import ImgLogo from '@/assets/images/Logo_2.png'
import ImgLeaf from '@/assets/images/leaf.png'
import { useAppDispatch, useAppSelector } from '@/hooks'
import { setToastData } from '@/slices/authSlice'

const AuthLayout = ({ children }: { children: React.ReactNode }) => {
  const dispatch = useAppDispatch()
  const toastData = useAppSelector((state) => state.auth.toastData)
  const isLoading = useAppSelector((state) => state.auth.isLoading)
  return (
    <>
      <div className="relative h-screen">
        <div className="flex flex-col items-center text-center p-5 h-full relative z-10">
          <img
            src={ImgLogo}
            alt="logo"
            className="mt-[37px] h-[105px] max-md:h-[70px]"
          />
          <div className="flex-grow flex flex-col items-center mx-5">
            {children}
          </div>
          <p className="text-center text-sm text-gray-500 py-[38px] w-full">
            By signing in & continuing you agree to our{' '}
            <span className="text-green underline cursor-pointer">
              Terms & Conditions
            </span>{' '}
            and{' '}
            <span className="text-green underline cursor-pointer">
              Privacy Policy
            </span>
          </p>
        </div>
        <img
          className="fixed bottom-0 left-0 h-[321px] max-md:h-[250px]"
          src={ImgLeaf}
          alt="logo"
        />
      </div>
      {toastData.msg?.length > 0 && (
        <Toast
          title="Important Alert!"
          message={toastData.msg}
          type={toastData.type as 'success' | 'failure' | 'info'}
          onClose={() => {
            dispatch(setToastData({}))
          }}
        />
      )}
      <LoaderModal isLoading={isLoading} />
    </>
  )
}

export default AuthLayout
