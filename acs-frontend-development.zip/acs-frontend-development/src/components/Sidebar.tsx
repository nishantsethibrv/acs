import classNames from 'classnames'
import ImgLogo from '@/assets/images/Logo.png'
import HomeIcon from '@/assets/icons/Home.svg?react'
import CalendarIcon from '@/assets/icons/Calendar.svg?react'
import ClockIcon from '@/assets/icons/Clock.svg?react'
import { Link, useLocation } from 'react-router-dom'

const sidebarItems = [
  { label: 'Dashboard', href: '/', icon: HomeIcon },
  { label: 'Assignments', href: '/assignments', icon: CalendarIcon },
  { label: 'Invoices', href: '/invoices', icon: ClockIcon },
]

type SidebarItem = (typeof sidebarItems)[0]

function BtnSidebarNav({
  item,
  isActive,
}: {
  item: SidebarItem
  isActive: boolean
}) {
  return (
    <div className="flex flex-col items-center mt-8">
      <Link
        className={classNames('fab', {
          active: isActive,
        })}
        to={item.href}
      >
        <item.icon />
      </Link>
      <span
        className={classNames('text-13 font-medium mt-[10px]', {
          'text-primary': !isActive,
          'text-secondary': isActive,
        })}
      >
        {item.label}
      </span>
    </div>
  )
}

const Sidebar = () => {
  const location = useLocation()

  return (
    <div className="flex flex-col items-center fixed top-0 bottom-0 left-0 z-30 bg-white overflow-y-auto p-5 custom-scrollbar">
      <img src={ImgLogo} alt="logo" height={100} width={100} />
      {sidebarItems.map((item) => (
        <BtnSidebarNav
          key={item.label}
          item={item}
          isActive={item.href === location.pathname}
        />
      ))}
    </div>
  )
}

export default Sidebar
