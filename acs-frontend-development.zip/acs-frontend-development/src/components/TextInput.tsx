import classNames from 'classnames'

type TextInputProps = {
  leading?: React.ReactNode
  trailing?: React.ReactNode
  inputClassName?: string
} & React.ComponentProps<'input'>

const TextInput = ({
  leading,
  trailing,
  className,
  inputClassName,
  ...rest
}: TextInputProps) => {
  return (
    <div
      className={classNames('textinput-1 flex items-center w-full', className)}
    >
      {leading}
      <input
        {...rest}
        className={classNames(
          'outline-none bg-transparent placeholder-primary-300 w-full',
          inputClassName
        )}
      />
      {trailing}
    </div>
  )
}

TextInput.defaultProps = {
  type: 'text',
}

export default TextInput
