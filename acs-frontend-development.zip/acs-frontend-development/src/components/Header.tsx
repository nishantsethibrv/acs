import { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import Dropdown from './Dropdown'
import ModalWrapper from './ModalWrapper'
import ImgUser from '@/assets/images/User.png'
import HomeIcon from '@/assets/icons/Home_2.svg?react'
import NotificationIcon from '@/assets/icons/Notification.svg?react'
import { useAppDispatch, useAppSelector } from '@/hooks'
import { startLogout } from '@/slices/authSlice'

const dropdownOptions = [
  { label: 'Contact Us', value: 'contactUs' },
  { label: 'Terms and Conditions', value: 'termsConditions' },
  { label: 'Privacy and Policy', value: 'privacyPolicy' },
  { label: 'Log Out', value: 'logOut' },
]

const Header = () => {
  const { pathname } = useLocation()
  const dispatch = useAppDispatch()
  const navigate = useNavigate()
  const [isConfirmLogout, setIsConfirmLogout] = useState(false)
  const userProfile = useAppSelector((state) => state.user.profile)
  const isSignedOut = useAppSelector((state) => state.auth.isSignedOut)

  useEffect(() => {
    if (isSignedOut) {
      // navigate('/login')
      navigate(0)
    }
  }, [navigate, isSignedOut])

  const getHeaderTitle = () => {
    if (pathname.startsWith('/assignments')) return 'Manage Assignments'
    if (pathname.startsWith('/invoices')) return 'Invoices'
    return 'Dashboard'
  }

  const handleDropdownSelect = (option: any) => {
    switch (option.value) {
      case 'logOut': {
        setIsConfirmLogout(true)
        // dispatch(startLogout())
        return
      }
    }
  }

  return (
    <>
      <div className="">
        {/* Breadcrumb */}
        <div>
          <div className="flex items-center">
            <HomeIcon />
            <span className="pl-[6px] pt-[2px] text-13 text-gray-590 font-medium">
              {getHeaderTitle()}
            </span>
          </div>
        </div>
        {/* Header Controls */}
        <div className="mt-6 flex items-center justify-between">
          <p className="text-primary text-[26px] font-medium">
            {getHeaderTitle()}
          </p>
          <div className="flex items-center ml-4">
            <div>
              <NotificationIcon />
            </div>
            <span className="text-gray-350 mx-4">|</span>
            <Dropdown options={dropdownOptions} onChange={handleDropdownSelect}>
              <div className="flex items-center cursor-pointer">
                <img className="rounded-full size-8" src={ImgUser} />
                <div className="px-[10px] max-lg:hidden">
                  <p className="text-15 font-medium">
                    {userProfile?.first_name} {userProfile?.last_name}
                  </p>
                  <p className="text-13 text-primary">{userProfile?.email}</p>
                </div>
              </div>
            </Dropdown>
          </div>
        </div>
      </div>
      {isConfirmLogout && (
        <ModalWrapper
          isOpen
          closeOnEsc
          closeOnOutsideClick
          onClose={() => setIsConfirmLogout(false)}
        >
          <div className="min-w-96 bg-white rounded-xl p-4 absolute-center">
            <p className="font-bold text-lg">Confirm Logout</p>
            <p className="text-gray-900 my-2">
              Are you sure you want to log out?
            </p>
            <div className="mt-6 flex items-center justify-end">
              <button
                className="btn-outline"
                onClick={() => setIsConfirmLogout(false)}
              >
                Cancel
              </button>
              <button
                className="ml-2 btn-primary"
                onClick={() => {
                  dispatch(startLogout())
                }}
              >
                Log Out
              </button>
            </div>
          </div>
        </ModalWrapper>
      )}
    </>
  )
}

export default Header
