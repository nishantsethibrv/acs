import { formatTime, getDuration, getMinutesDiff } from '@/utils/dateTime'

type IntervalChipProps = {
  /**eg. 22:00:00 */
  startTime: string
  /**eg. 23:30:00 */
  endTime: string
  /** YYYY-MM-DD eg. 2024-04-04 */
  date: string
  onClick?: () => void
  color1: string
  color2: string
}
const IntervalChip = ({
  startTime,
  endTime,
  date,
  onClick,
  color1,
  color2,
}: IntervalChipProps) => {
  const left = getMinutesDiff('00:00:00', startTime) + 50
  const width = getMinutesDiff(startTime, endTime)
  const d = new Date(date).getDate()
  const top = (d - 1) * 70 + 8

  return (
    <tr>
      <td
        className="absolute z-[8] w-[120px] text-gray-700 text-13 font-medium py-[7px] px-[15px] rounded-[9px] cursor-pointer"
        style={{ left, width, top, background: color1 }}
        onClick={onClick}
      >
        <div
          className="absolute left-0 top-1/2 transform -translate-y-1/2 h-6 w-1 rounded-full"
          style={{ background: color2 }}
        ></div>
        <p className="overflow-ellipsis">
          {formatTime(startTime)} - {formatTime(endTime)}
        </p>
        <p className="overflow-ellipsis">{getDuration(startTime, endTime)}</p>
      </td>
    </tr>
  )
}

export default IntervalChip
