import { useEffect, useMemo, useRef } from 'react'
import IntervalChip from './IntervalChip'
import { getDatesInMonth } from '@/utils/dateTime'

const times = Array.from(Array(25).keys())

type SchedulerProps = {
  year: number
  month: number
  schedule: {
    uniqueKey: string
    shiftId: number
    /** Format: HH:MM:SS */
    startTime: string
    /** Format: HH:MM:SS */
    endTime: string
    /** Format: YYYY-MM-DD */
    date: string
    color1: string
    color2: string
  }[]
  onShiftClick?: (shiftId: number) => void
}

function ScheduleView({ year, month, schedule, onShiftClick }: SchedulerProps) {
  const currDateRef = useRef<HTMLTableRowElement>(null)
  const currDate = useMemo(() => new Date(), [])
  const dates = useMemo(() => {
    return getDatesInMonth(year, month)
  }, [year, month])

  useEffect(() => {
    if (
      currDateRef?.current &&
      currDate.getFullYear() === year &&
      currDate.getMonth() + 1 === month
    ) {
      currDateRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }, [currDate, month, year])

  return (
    <div className="overflow-auto relative max-w-full min-h-[250px] max-h-[calc(100vh-230px)] custom-scrollbar">
      <table>
        <thead className="sticky top-0 left-0 right-0 z-20 h-12 bg-white">
          <tr>
            {times.map((t) => (
              <th
                className="translate-x-1/2 text-gray-590 text-13 font-normal bg-white"
                key={t}
              >
                {t.toString().padStart(2, '0')}:00
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="relative">
          {dates.map((d, i) => {
            return (
              <tr
                className="h-[70px]"
                key={d}
                ref={i === currDate.getDate() - 2 ? currDateRef : null}
              >
                <td className="sticky top-0 left-0 right-0 z-10 bg-white text-13 font-medium text-primary min-w-[50px] max-w-[50px] border-r border-gray-200">
                  <p className="inline-block transform rotate-[-45deg] p-1">
                    {d}
                  </p>
                </td>
                {Array.from(Array(24).keys()).map((t) => (
                  <td
                    key={t}
                    className="min-w-[60px] max-w-[60px] border-r border-gray-200"
                  />
                ))}
              </tr>
            )
          })}
          {schedule.map((shift) => (
            <IntervalChip
              key={shift.uniqueKey}
              {...shift}
              onClick={() => {
                onShiftClick && onShiftClick(shift.shiftId)
              }}
            />
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default ScheduleView
