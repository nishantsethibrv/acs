import classNames from 'classnames'

type DropdownItemProps = {
  label: string
  isSelected: boolean
  onClick: () => void
  className?: string
}
const DropdownItem = ({
  label,
  isSelected,
  onClick,
  className,
}: DropdownItemProps) => {
  return (
    <div
      className={classNames('dropdown-item', className, {
        'bg-primary text-white': isSelected,
      })}
      onClick={onClick}
    >
      <p className="m-0 overflow-ellipsis ">{label}</p>
    </div>
  )
}

export default DropdownItem
