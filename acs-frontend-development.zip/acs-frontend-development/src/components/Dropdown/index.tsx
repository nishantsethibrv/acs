import { useState } from 'react'
import DropdownWrapper from './DropdownWrapper'
import DropdownItem from './DropdownItem'

export type DropdownOption = {
  label: string
  value: string
} & Record<string, any>

type DropdownProps = {
  options: DropdownOption[]
  selectedValue?: string
  placeholder?: string
  onChange?: (optoin: DropdownOption) => void
  isClearOnSelect?: boolean
  wrapperClass?: string
  targetClass?: string
  contentClass?: string
  itemClass?: string
  children?: React.ReactNode
}

const Dropdown = ({
  options,
  selectedValue,
  onChange,
  wrapperClass,
  contentClass,
  itemClass,
  children,
}: DropdownProps) => {
  const [isOpen, setIsOpen] = useState(false)

  const isSelected = (option: DropdownOption) => {
    return selectedValue === option.value
  }

  const handleItemClick = (option: DropdownOption) => {
    onChange && onChange(option)
    setIsOpen(false)
  }

  return (
    <DropdownWrapper
      isOpen={isOpen}
      setIsOpen={setIsOpen}
      target={children}
      className={wrapperClass}
      contentClass={contentClass}
    >
      {options?.map((option) => (
        <DropdownItem
          key={option.value}
          label={option.label}
          isSelected={isSelected(option)}
          onClick={() => handleItemClick(option)}
          className={itemClass}
        />
      ))}
    </DropdownWrapper>
  )
}

export default Dropdown
