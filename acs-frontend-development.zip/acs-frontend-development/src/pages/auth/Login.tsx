import { useEffect, useMemo, useState } from 'react'
import { NavLink, useLocation, useNavigate } from 'react-router-dom'
import { useFormik } from 'formik'
import classNames from 'classnames'
import AuthLayout from '@/components/layout/AuthLayout'
import TextInput from '@/components/TextInput'
import ArrowForwardIcon from '@/assets/icons/Arrow_Forward.svg?react'
import VisibilityIcon from '@/assets/icons/Visibility.svg?react'
import VisibilityOffIcon from '@/assets/icons/Visibility_Off.svg?react'
import { useAppDispatch, useAppSelector } from '@/hooks'
import { resetState, setErrorMsg, startLogin } from '@/slices/authSlice'
import { getUserProfile } from '@/slices/userSlice'
import { validateEmail } from '@/utils/validators'

type FormValues = {
  email: string
  password: string
}
type FormError = {
  email?: string
  password?: string
}
const validate = (values: FormValues) => {
  const errors: FormError = {}
  const emailErr = validateEmail(values.email)
  if (emailErr) {
    errors.email = emailErr
  }
  if (!values.password || values.password === '') {
    errors.password = 'Password is required'
  }
  return errors
}

const Login = () => {
  const location = useLocation()
  const navigate = useNavigate()
  const dispatch = useAppDispatch()
  const [isPasswordVisible, setIsPasswordVisible] = useState(false)
  const authState = useAppSelector((state) => state.auth)
  const from = (location.state?.pathname as string) || '/'

  const formik = useFormik<FormValues>({
    initialValues: { email: '', password: '' },
    validate,
    onSubmit: (values) => {
      dispatch(startLogin(values))
    },
  })

  const isDisabled: boolean =
    !(Object.keys(formik.touched).length > 0) || !formik.isValid

  const errors = useMemo(() => {
    const e: FormError = {}
    if (formik.touched.email && formik.errors.email) {
      e.email = formik.errors.email
    } else if (authState.errorMsg.includes('email is incorrect')) {
      e.email = authState.errorMsg
    }
    if (formik.touched.password && formik.errors.password) {
      e.password = formik.errors.password
    } else if (authState.errorMsg.includes('password is incorrect')) {
      e.password = authState.errorMsg
    }
    return e
  }, [formik.touched, formik.errors, authState.errorMsg])

  useEffect(() => {
    if (authState.isSignedIn) {
      navigate(from, { replace: true })
      dispatch(getUserProfile())
      dispatch(resetState())
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [navigate, from, authState.isSignedIn])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    dispatch(setErrorMsg(''))
    formik.handleChange(e)
  }

  return (
    <AuthLayout>
      <p className="text-primary text-[39px] font-medium mb-[13px] mt-[121px] max-md:mt-[70px] max-md:text-[30px]">
        Hi, Welcome Back!
      </p>
      <p className="text-17 text-gray-900 max-md:text-15">
        We are looking forward to working for you today. Please input your login
        details, and let's get started.
      </p>
      <form
        className="max-w-[370px] flex flex-col items-center mt-[96px] max-md:mt-[60px] "
        onSubmit={formik.handleSubmit}
      >
        <TextInput
          value={formik.values.email}
          onChange={(e) => {
            if (!validateEmail(e.target.value)) {
              formik.setFieldTouched('email', true)
            }
            handleInputChange(e)
          }}
          onBlur={formik.handleBlur}
          name="email"
          type="email"
          placeholder="Email*"
          className={classNames({
            invalid: errors.email,
          })}
          inputClassName="text-center"
        />
        {errors.email && <p className="form-error">{errors.email}</p>}
        <TextInput
          value={formik.values.password}
          onChange={handleInputChange}
          onBlur={formik.handleBlur}
          name="password"
          type={isPasswordVisible ? 'text' : 'password'}
          placeholder="Password*"
          className={classNames('mt-[21px]', {
            invalid: errors.password,
          })}
          inputClassName="text-center"
          trailing={
            isPasswordVisible ? (
              <VisibilityOffIcon
                className="fill-primary-300 cursor-pointer ml-2"
                onClick={() => setIsPasswordVisible(!isPasswordVisible)}
              />
            ) : (
              <VisibilityIcon
                className="fill-primary-300 cursor-pointer ml-2"
                onClick={() => setIsPasswordVisible(!isPasswordVisible)}
              />
            )
          }
        />
        {errors.password && <p className="form-error">{errors.password}</p>}
        <div className="flex justify-end mt-[11px] w-full">
          <NavLink
            to="/forgot-password"
            className="text-secondary text-sm cursor-pointer disable-select"
          >
            Forgot Password?
          </NavLink>
        </div>
        <button
          className="h-[52px] w-[52px] fab-circle my-[46px]"
          type="submit"
          disabled={isDisabled}
        >
          <ArrowForwardIcon />
        </button>
      </form>
    </AuthLayout>
  )
}

export default Login
