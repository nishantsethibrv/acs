import { useMemo } from 'react'
import { useFormik } from 'formik'
import classNames from 'classnames'
import ArrowForwardIcon from '@/assets/icons/Arrow_Forward.svg?react'
import TextInput from '@/components/TextInput'
import { useAppDispatch, useAppSelector } from '@/hooks'
import { forgotPasswordSendOTP, setErrorMsg } from '@/slices/authSlice'
import { validateEmail } from '@/utils/validators'

type FormValues = {
  email: string
}
type FormError = {
  email?: string
}

const validate = (values: FormValues) => {
  const errors: FormError = {}
  const emailErr = validateEmail(values.email)
  if (emailErr) {
    errors.email = emailErr
  }
  return errors
}

const EmailInputForm = () => {
  const dispatch = useAppDispatch()
  const authState = useAppSelector((state) => state.auth)

  const formik = useFormik<FormValues>({
    initialValues: { email: '' },
    validate,
    onSubmit: (values) => {
      dispatch(forgotPasswordSendOTP(values))
    },
  })

  const isDisabled: boolean =
    !(Object.keys(formik.touched).length > 0) || !formik.isValid

  //Handle api errors and frontend validation errors
  const errors = useMemo(() => {
    const e: FormError = {}
    if (formik.touched.email && formik.errors.email) {
      e.email = formik.errors.email
    } else if (authState.errorMsg.trim().length) {
      e.email = authState.errorMsg
    }
    return e
  }, [formik.touched, formik.errors, authState.errorMsg])

  return (
    <>
      <p className="text-primary text-[39px] font-medium mb-[13px] mt-[121px] max-md:mt-[70px] max-md:text-[30px]">
        Need Help Recovering Your Password?
      </p>
      <p className="text-17 text-gray-900 max-md:text-15">
        Please enter your registered email.
      </p>
      <form
        className="max-w-[370px] flex flex-col items-center mt-[96px] max-md:mt-[60px]"
        onSubmit={formik.handleSubmit}
      >
        <TextInput
          value={formik.values.email}
          onChange={(e) => {
            if (!validateEmail(e.target.value)) {
              formik.setFieldTouched('email', true)
            }
            dispatch(setErrorMsg(''))
            formik.handleChange(e)
          }}
          onBlur={formik.handleBlur}
          name="email"
          type="email"
          placeholder="Registered Email*"
          className={classNames({
            invalid: errors.email,
          })}
          inputClassName="text-center"
        />
        {errors.email && <p className="form-error">{errors.email}</p>}

        <button
          className="h-[52px] w-[52px] fab-circle my-[46px]"
          type="submit"
          disabled={isDisabled}
        >
          <ArrowForwardIcon />
        </button>
      </form>
    </>
  )
}

export default EmailInputForm
