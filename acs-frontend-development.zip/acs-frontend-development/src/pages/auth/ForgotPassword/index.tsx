import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import AuthLayout from '@/components/layout/AuthLayout'
import EmailInputForm from './EmailInputForm'
import OTPInputForm from './OTPInputForm'
import PasswordInputForm from './PasswordInputForm'
import { useAppDispatch, useAppSelector } from '@/hooks'
import { resetState } from '@/slices/authSlice'

const ForgotPassword = () => {
  const navigate = useNavigate()
  const dispatch = useAppDispatch()
  const forgotPasswordState = useAppSelector(
    (state) => state.auth.forgotPassword
  )

  useEffect(() => {
    if (forgotPasswordState.passwordCreated) {
      navigate('/login', { replace: true })
      dispatch(resetState())
    }
  }, [navigate, dispatch, forgotPasswordState.passwordCreated])

  return (
    <AuthLayout>
      {!forgotPasswordState.otpSent && <EmailInputForm />}
      {forgotPasswordState.otpSent && !forgotPasswordState.optVerified && (
        <OTPInputForm />
      )}
      {forgotPasswordState.optVerified && <PasswordInputForm />}
    </AuthLayout>
  )
}

export default ForgotPassword
