import { useMemo, useState } from 'react'
import { useFormik } from 'formik'
import classNames from 'classnames'
import TextInput from '@/components/TextInput'
import ArrowForwardIcon from '@/assets/icons/Arrow_Forward.svg?react'
import VisibilityIcon from '@/assets/icons/Visibility.svg?react'
import VisibilityOffIcon from '@/assets/icons/Visibility_Off.svg?react'
import { useAppDispatch, useAppSelector } from '@/hooks'
import { createNewPassword, setErrorMsg } from '@/slices/authSlice'
import { validateConfirmPassword, validatePassword } from '@/utils/validators'

type FormValues = {
  newPassword: string
  confirmPassword: string
}

type FormError = {
  newPassword?: string
  confirmPassword?: string
}

const validate = (values: FormValues) => {
  const errors: FormError = {}
  const pswdErr = validatePassword(values.newPassword)
  const cfPswdErr = validateConfirmPassword(
    values.newPassword,
    values.confirmPassword
  )
  if (pswdErr) {
    errors.newPassword = pswdErr
    errors.confirmPassword = pswdErr
  } else if (cfPswdErr) {
    errors.newPassword = cfPswdErr
    errors.confirmPassword = cfPswdErr
  }
  return errors
}

const PasswordInputForm = () => {
  const dispatch = useAppDispatch()
  const [isPasswordVisible, setIsPasswordVisible] = useState(false)
  const [isCfPasswordVisible, setIsCfPasswordVisible] = useState(false)
  const authState = useAppSelector((state) => state.auth)

  const formik = useFormik<FormValues>({
    initialValues: { newPassword: '', confirmPassword: '' },
    validate,
    onSubmit: (values) => {
      dispatch(createNewPassword(values))
    },
  })

  const isDisabled: boolean =
    !(Object.keys(formik.touched).length > 0) || !formik.isValid

  //Handle api errors and frontend validation errors
  const errors = useMemo(() => {
    const e: FormError = {}
    if (
      (formik.touched.newPassword && formik.errors.newPassword) ||
      (formik.touched.confirmPassword && formik.errors.confirmPassword)
    ) {
      e.newPassword = formik.errors.newPassword || formik.errors.confirmPassword
      e.confirmPassword = e.newPassword
    } else if (authState.errorMsg.trim().length) {
      e.newPassword = authState.errorMsg
      e.confirmPassword = authState.errorMsg
    }
    return e
  }, [formik.touched, formik.errors, authState.errorMsg])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    dispatch(setErrorMsg(''))
    formik.handleChange(e)
  }

  return (
    <>
      <p className="text-primary text-[39px] font-medium mb-[13px] mt-[121px] max-md:mt-[70px] max-md:text-[30px]">
        Need Help Recovering Your Password?
      </p>
      <p className="text-17 text-gray-900 max-md:text-15">
        Create new password.
      </p>
      <form
        className="max-w-[370px] flex flex-col items-center mt-[96px] max-md:mt-[60px] "
        onSubmit={formik.handleSubmit}
      >
        <TextInput
          value={formik.values.newPassword}
          onChange={handleInputChange}
          onBlur={formik.handleBlur}
          name="newPassword"
          type={isPasswordVisible ? 'text' : 'password'}
          placeholder="New Password*"
          className={classNames('mb-[21px]', {
            invalid: errors.newPassword,
          })}
          inputClassName="text-center"
          trailing={
            isPasswordVisible ? (
              <VisibilityOffIcon
                className="fill-primary-300 cursor-pointer ml-2"
                onClick={() => setIsPasswordVisible(!isPasswordVisible)}
              />
            ) : (
              <VisibilityIcon
                className="fill-primary-300 cursor-pointer ml-2"
                onClick={() => setIsPasswordVisible(!isPasswordVisible)}
              />
            )
          }
        />
        <TextInput
          value={formik.values.confirmPassword}
          onChange={handleInputChange}
          onBlur={formik.handleBlur}
          name="confirmPassword"
          type={isCfPasswordVisible ? 'text' : 'password'}
          placeholder="Confirm Password*"
          className={classNames({
            invalid: errors.confirmPassword,
          })}
          inputClassName="text-center"
          trailing={
            isCfPasswordVisible ? (
              <VisibilityOffIcon
                className="fill-primary-300 cursor-pointer ml-2"
                onClick={() => setIsCfPasswordVisible(!isCfPasswordVisible)}
              />
            ) : (
              <VisibilityIcon
                className="fill-primary-300 cursor-pointer ml-2"
                onClick={() => setIsCfPasswordVisible(!isCfPasswordVisible)}
              />
            )
          }
        />
        {errors.newPassword && (
          <p className="form-error">{errors.newPassword}</p>
        )}
        <button
          className="h-[52px] w-[52px] fab-circle my-[46px]"
          type="submit"
          disabled={isDisabled}
        >
          <ArrowForwardIcon />
        </button>
      </form>
    </>
  )
}

export default PasswordInputForm
