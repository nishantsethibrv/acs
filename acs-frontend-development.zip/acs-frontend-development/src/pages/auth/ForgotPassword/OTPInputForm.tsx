import { useEffect, useMemo, useState } from 'react'
import { useFormik } from 'formik'
import classNames from 'classnames'
import OtpInput from '@/components/OtpInput'
import ArrowForwardIcon from '@/assets/icons/Arrow_Forward.svg?react'
import LoopIcon from '@/assets/icons/Loop.svg?react'
import { useAppDispatch, useAppSelector } from '@/hooks'
import {
  forgotPasswordSendOTP,
  forgotPasswordVerifyOTP,
  setErrorMsg,
} from '@/slices/authSlice'

type FormValues = {
  otp: string
}

type FormError = {
  otp?: string
}

const OTPInputForm = () => {
  const dispatch = useAppDispatch()
  const authState = useAppSelector((state) => state.auth)
  const [timer, setTimer] = useState(120)

  const formik = useFormik<FormValues>({
    initialValues: { otp: '' },
    onSubmit: (values) => {
      dispatch(forgotPasswordVerifyOTP(values))
    },
  })

  const isDisabled: boolean = formik.values.otp.length < 4

  //Handle api errors and frontend validation errors
  const errors = useMemo(() => {
    const e: FormError = {}
    if (authState.errorMsg.trim().length) {
      e.otp = authState.errorMsg
    }
    return e
  }, [authState.errorMsg])

  useEffect(() => {
    if (authState.forgotPassword.resendOtpCount) {
      setTimer(120)
    }
    const interval = setInterval(() => {
      setTimer((prev) => {
        if (prev === 0) {
          clearInterval(interval)
          return 0
        }
        return prev - 1
      })
    }, 1000)
    return () => {
      clearInterval(interval)
    }
  }, [authState.forgotPassword.resendOtpCount])

  const getTimer = () => {
    const mm = Math.floor(timer / 60)
    const ss = timer % 60
    return `${mm < 10 ? '0' + mm : mm}:${ss < 10 ? '0' + ss : ss}`
  }

  const handleResendCodeClick = () => {
    if (timer !== 0) {
      return
    }
    dispatch(forgotPasswordSendOTP({ email: authState.forgotPassword.email }))
  }

  return (
    <>
      <p className="text-primary text-[39px] font-medium mb-[13px] mt-[121px] max-md:mt-[70px] max-md:text-[30px]">
        Please Verify Your Provided Email
      </p>
      <p className="text-17 text-gray-900 max-md:text-15">
        Kindly provide the verification code sent to your email{' '}
        <span className="font-semibold">{authState.forgotPassword.email}</span>
      </p>
      <form
        className="max-w-[370px] flex flex-col items-center mt-[96px] max-md:mt-[60px] "
        onSubmit={formik.handleSubmit}
      >
        <OtpInput
          length={4}
          onChange={(val) => {
            dispatch(setErrorMsg(''))
            formik.setFieldValue('otp', val)
          }}
          inputClassName={classNames({
            invalid: errors.otp,
          })}
        />
        {errors.otp && (
          <p className="form-error text-center mt-[20px]">{errors.otp}</p>
        )}
        <button
          className="h-[52px] w-[52px] fab-circle my-[46px]"
          type="submit"
          disabled={isDisabled}
        >
          <ArrowForwardIcon />
        </button>

        <div
          className={classNames('flex items-center mt-[40px] px-2', {
            'cursor-pointer': timer === 0,
          })}
          onClick={handleResendCodeClick}
        >
          <LoopIcon className="fill-green" />
          <span className="ps-2 text-green text-15">
            {timer === 0 ? 'Resend Code' : getTimer()}
          </span>
        </div>
        {authState.forgotPassword.resendOtpCount > 0 && timer !== 0 && (
          <p className="text-15 text-center text-gray-900 mt-[18px]">
            You will receive a new code on the email you provided. Please
            attempt to enter the code again and click on "continue".
          </p>
        )}
      </form>
    </>
  )
}

export default OTPInputForm
