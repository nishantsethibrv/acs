import { useEffect, useMemo } from 'react'
import { useDispatch } from 'react-redux'
import InvoiceItem from './InvoiceItem'
import Loader from '@/components/Loader'
import ForwardIcon from '@/assets/icons/Arrow_Forward.svg?react'
import BackwardIcon from '@/assets/icons/Arrow_Backward.svg?react'
import { useAppSelector } from '@/hooks'
import { getInvoices, setNextYear, setPrevYear } from '@/slices/invoicesSlice'
import { monthsLong, monthsShort } from '@/utils/dateTime'
import { downloadFile } from '@/utils/fileUtil'

const Invoices = () => {
  const dispatch = useDispatch()
  const invoicesState = useAppSelector((state) => state.invoices)
  const invoices = invoicesState.allInvoices.items
  const selectedYear = invoicesState.year

  const invoiceItems = useMemo(() => {
    const mappedInvoices: Record<string, Record<string, any>[]> = {}
    for (const invoice of invoices) {
      if (!mappedInvoices[invoice.month]) {
        mappedInvoices[invoice.month] = [invoice]
      } else {
        mappedInvoices[invoice.month].push(invoice)
      }
    }
    return mappedInvoices
  }, [invoices])

  useEffect(() => {
    dispatch(getInvoices())
  }, [dispatch, selectedYear])

  const handleNextYearClick = () => {
    dispatch(setNextYear())
  }
  const handlePrevYearClick = () => {
    dispatch(setPrevYear())
  }

  return (
    <div className="mt-9">
      <div className="flex">
        <button className="btn-primary px-3" onClick={handlePrevYearClick}>
          <BackwardIcon className="size-3" />
        </button>
        <button className="btn-secondary px-4 mx-[10px] text-nowrap min-w-[140px]">
          {selectedYear}
        </button>
        <button className="btn-primary px-3" onClick={handleNextYearClick}>
          <ForwardIcon className="size-3" />
        </button>
      </div>
      {invoicesState.allInvoices.isLoading ? (
        <Loader center />
      ) : !invoicesState.allInvoices.items?.length ? (
        <p className="py-10">No Invoices Found</p>
      ) : (
        <div className="mt-4 min-h-[250px] max-h-[calc(100vh-225px)] overflow-y-auto custom-scrollbar">
          {monthsShort.map((month, i) => {
            if (invoiceItems[month]) {
              return (
                <div className="pt-9" key={month}>
                  <p className="text-xl">
                    {monthsLong[i]} {selectedYear}
                  </p>
                  <div className="grid grid-cols-4 max-xl:grid-cols-3 max-lg:grid-cols-2 max-sm:grid-cols-1 gap-5 mt-6 items-start">
                    {invoiceItems[month].map((invoice) => (
                      <InvoiceItem
                        key={invoice.id}
                        title={invoice.invoice_name || 'invoice'}
                        startDate={new Date(invoice.start_date)}
                        endDate={new Date(invoice.end_date)}
                        onClick={() => {
                          downloadFile(
                            invoice.invoice_url,
                            invoice.invoice_name || 'invoice'
                          )
                        }}
                      />
                    ))}
                  </div>
                </div>
              )
            }
          })}
        </div>
      )}
    </div>
  )
}

export default Invoices
