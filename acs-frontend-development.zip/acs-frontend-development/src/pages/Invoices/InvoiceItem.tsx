// import ClockIcon from '@/assets/icons/Clock_2.svg?react'
import DownloadIcon from '@/assets/icons/Download_File.svg?react'

type InvoiceItemProps = {
  title: string
  startDate: Date
  endDate: Date
  onClick?: () => void
}

const InvoiceItem = ({
  title,
  startDate,
  endDate,
  onClick,
}: InvoiceItemProps) => {
  return (
    <div>
      <p>
        {` ${startDate.getOridinalDate()} ${startDate.getMonthString()} - ${endDate.getOridinalDate()} ${endDate.getMonthString()}`}
      </p>
      <div
        className="flex items-center py-[10px] px-[14px] my-3 rounded-[7px] cursor-pointer bg-primary-200"
        onClick={onClick}
      >
        <div className="flex-grow overflow-hidden">
          {/* <div className="flex items-center">
            <ClockIcon className="fill-primary size-[10px]" />
            <p className="text-primary text-13 ml-1 mt-[2px]">
              5 Feb 2024 - 12 Feb 2024
            </p>
          </div> */}
          <p className="text-13 text-gray-900 overflow-ellipsis">{title}</p>
        </div>
        <div className="p-1">
          <DownloadIcon className="size-4" />
        </div>
      </div>
    </div>
  )
}

export default InvoiceItem
