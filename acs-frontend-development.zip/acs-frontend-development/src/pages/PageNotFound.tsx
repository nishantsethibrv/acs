import { Link } from 'react-router-dom'

const PageNotFound = () => {
  return (
    <div className="p-3 absolute-center text-center">
      <p className="font-bold text-4xl text-primary">404</p>
      <p className="mt-2 text-gray-900 text-lg">Page Not Found</p>
      <Link to="/" className="block mt-5 btn-primary">
        Back To Home
      </Link>
    </div>
  )
}

export default PageNotFound
