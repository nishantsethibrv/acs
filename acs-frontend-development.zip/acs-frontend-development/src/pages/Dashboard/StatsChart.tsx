import { Chart } from 'react-google-charts'

type StatsChartProps = {
  completedAssignments: number
  pendingAssignments: number
  confirmedAssignments: number
}
const StatsChart = ({
  completedAssignments,
  pendingAssignments,
  confirmedAssignments,
}: StatsChartProps) => {
  const isEmpty =
    !completedAssignments && !pendingAssignments && !confirmedAssignments
  let data = [
    ['Assignments', 'Count'],
    ['Completed Assignments', completedAssignments],
    ['Pending Assignments', pendingAssignments],
    ['Confirmed Assignments', confirmedAssignments],
  ]
  let colors = ['#31F258', '#FF9E9E', '#37D499']

  if (isEmpty) {
    data = [
      ['Assignments', 'Count'],
      ['No Assignments', 100],
    ]
    colors = ['#AFAFAF']
  }
  return (
    <div className="google-chart-tooltip">
      <Chart
        chartType="PieChart"
        width="500px"
        height="300px"
        data={data}
        options={{
          backgroundColor: 'transparent',
          pieHole: 0.5,
          is3D: false,
          legend: {
            position: 'right',
            alignment: 'center',
            textStyle: {
              color: '#707070',
            },
          },
          chartArea: { width: '95%', height: '95%' },
          colors,
          tooltip: isEmpty ? { trigger: 'none' } : null,
          sliceVisibilityThreshold: 0,
        }}
      />
    </div>
  )
}

export default StatsChart
