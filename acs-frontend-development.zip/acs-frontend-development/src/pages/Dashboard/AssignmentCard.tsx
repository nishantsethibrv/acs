import ImgUser from '@/assets/images/User.png'
import ClockIcon from '@/assets/icons/Clock_2.svg?react'
import CalendarIcon from '@/assets/icons/Calendar_2.svg?react'
import { formatTime, getDuration } from '@/utils/dateTime'

type AssignmentCardProps = {
  title: string
  startTime: string
  endTime: string
  startDate: string
  description: string
  owner: string
  onClick: () => void
}
const AssignmentCard = ({
  title,
  startTime,
  endTime,
  startDate,
  description,
  owner,
  onClick,
}: AssignmentCardProps) => {
  return (
    <div
      onClick={onClick}
      className="bg-gray-100 rounded-2xl p-[15px] flex flex-col w-full items-start cursor-pointer"
    >
      <p className="text-primary text-lg font-medium">{title}</p>
      <div className="flex items-center mt-2">
        <ClockIcon className="size-[14px] fill-gray-990" />
        <p className="text-15 text-gray-990 ml-[6px]">
          {formatTime(startTime)}-{formatTime(endTime)} •{' '}
          {getDuration(startTime, endTime)}
        </p>
      </div>
      <div className="flex items-center">
        <CalendarIcon className="size-[14px] fill-gray-990" />
        <p className="text-15 text-gray-990 ml-[6px]">
          {new Date(startDate).formatDateM3D2Y4()}
        </p>
      </div>
      <p className="text-13 text-gray-590  mt-[10px]">{description}</p>
      <div className="flex items-center justify-end mt-4 w-full">
        <img className="rounded-full size-4" src={ImgUser} />
        <span className="ml-[6px] text-13 text-gray-990 mt-[2px]">{owner}</span>
      </div>
    </div>
  )
}

export default AssignmentCard
