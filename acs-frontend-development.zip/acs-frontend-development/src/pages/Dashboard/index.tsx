import { useEffect } from 'react'
import classNames from 'classnames'
import StatCard from './StatCard'
import StatsChart from './StatsChart'
import AssignmentCard from './AssignmentCard'
import Loader from '@/components/Loader'
import { getDashboardData } from '@/slices/dashboardSlice'
import { useAppDispatch, useAppSelector } from '@/hooks'
import { getAssignmentDetails } from '@/slices/assignmentsSlice'
import ShiftDetails from '../Assignments/ShiftDetails'

const Dashboard = () => {
  const dispatch = useAppDispatch()
  const dashboardState = useAppSelector((state) => state.dashboard)
  const data = dashboardState.data

  useEffect(() => {
    dispatch(getDashboardData())
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  const handleAssignmentClick = (shiftId: number) => {
    dispatch(getAssignmentDetails({ shiftId }))
  }
  return (
    <>
      <div
        className={classNames({
          hidden: dashboardState.isLoading,
        })}
      >
        <div className="mt-[70px] grid grid-cols-2 max-xl:grid-cols-1">
          <div>
            <div className="w-full grid grid-cols-2 gap-5">
              <StatCard
                label="Confirmed Assignments"
                count={data?.confirmed_assignments ?? 'N/A'}
              />
              <StatCard
                label="Pending Assignments"
                count={data?.pending_assignment ?? 'N/A'}
              />
              <StatCard
                label="Current Invoice Hours"
                count={
                  data?.current_invoice_hours != null &&
                  data?.current_invoice_hours != undefined
                    ? `${data?.current_invoice_hours}hrs`
                    : 'N/A'
                }
              />
              <StatCard
                label="Completed Assignments"
                count={data?.completed_assignment ?? 'N/A'}
              />
              {/* {statItems.map((item) => (
              <StatCard key={item.label} {...item} />
            ))} */}
            </div>
          </div>
          <div className=" px-5 xl:ml-[40px] max-xl:mt-12 max-xl:flex-center max-md:hidden">
            <StatsChart
              completedAssignments={data?.completed_assignment}
              pendingAssignments={data?.pending_assignment}
              confirmedAssignments={data?.confirmed_assignments}
            />
          </div>
        </div>
        <div className="mt-[55px]">
          {/* Assignments */}
          <p className="text-lg text-gray-900">Latest Assignments</p>
          <div className="grid grid-cols-4 max-xl:grid-cols-3 max-lg:grid-cols-2 max-md:grid-cols-1 gap-5 mt-5 items-start">
            {data?.latest_assignments?.length ? (
              data?.latest_assignments.map((item: Record<string, any>) => (
                <AssignmentCard
                  key={item.shift_id}
                  title={item.job_title}
                  startTime={item.start_time}
                  endTime={item.end_time}
                  startDate={item.start_date}
                  description={item.notes}
                  owner={item.owner_name}
                  onClick={() => handleAssignmentClick(item.shift_id)}
                />
              ))
            ) : (
              <p className="p-6">No assignments found</p>
            )}
          </div>
        </div>
      </div>
      {dashboardState.isLoading && <Loader center />}
      <ShiftDetails />
    </>
  )
}

export default Dashboard
