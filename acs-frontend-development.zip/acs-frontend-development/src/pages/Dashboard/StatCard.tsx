type StatCardProps = {
  label: string
  count: string
}
const StatCard = ({ label, count }: StatCardProps) => {
  return (
    <div className="bg-gray-110 rounded-2xl p-5 max-lg:p-4 text-center">
      <p className="font-light text-gray-900 text-[45px] max-lg:text-4xl">
        {count}
      </p>
      <p className=" text-secondary text-15 max-lg:text-sm">{label}</p>
    </div>
  )
}

export default StatCard
