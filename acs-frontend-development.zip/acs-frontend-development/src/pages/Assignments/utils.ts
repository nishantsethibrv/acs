const colors = [
  { color1: '#F7F9B1', color2: '#c7cc00' },
  { color1: '#FFEBEB', color2: '#CE4E4E' },
  { color1: '#B8FFC6', color2: '#3AB152' },
  { color1: '#F1EBFF', color2: '#8F75CC' },
]
export const generateSchedule = (
  shifts: {
    shift_id: number
    start_date: string
    end_date: string | null | undefined
    start_time: string
    end_time: string
    days: string | null | undefined
  }[],
  selectedDate: Date
) => {
  const selectedMonth = selectedDate.getMonth()
  const selectedYear = selectedDate.getFullYear()
  const items: {
    uniqueKey: string
    shiftId: number
    date: string
    startTime: string
    endTime: string
    color1: string
    color2: string
  }[] = []
  for (let i = 0; i < shifts.length; i++) {
    const shift = shifts[i]
    let monthStartDate
    let monthEndDate
    if (shift.start_date) {
      monthStartDate = new Date(shift.start_date)
    } else {
      // First date of selected month
      monthStartDate = new Date(selectedYear, selectedMonth, 1)
    }
    if (shift.end_date) {
      monthEndDate = new Date(shift.end_date)
    } else {
      // Last date of selected month
      monthEndDate = new Date(selectedYear, selectedMonth + 1, 0)
    }

    const startMonth = monthStartDate.getMonth()

    if (selectedMonth > startMonth) {
      monthStartDate.setMonth(selectedMonth)
      monthStartDate.setDate(1)
    } else if (selectedMonth < startMonth) {
      console.log('Start month is ahead of current month')
      continue
    }
    const days = shift.days ? shift.days.split(',') : []

    while (
      monthStartDate.getFullYear() === selectedYear &&
      monthStartDate.getMonth() === selectedMonth &&
      monthStartDate <= monthEndDate
    ) {
      const shiftDate = monthStartDate.formatDateY4M2D2()
      const day = monthStartDate.getWeekdayString().toLowerCase().slice(0, 3)

      if (!days.length || days.includes(day)) {
        items.push({
          uniqueKey: `${shift.shift_id}_${shift.start_time}_${shiftDate}`,
          shiftId: shift.shift_id,
          date: shiftDate,
          startTime: shift.start_time,
          endTime: shift.end_time,
          color1: colors[i % 4].color1,
          color2: colors[i % 4].color2,
        })
      }
      monthStartDate.setDate(monthStartDate.getDate() + 1)
    }
  }
  return items
}
