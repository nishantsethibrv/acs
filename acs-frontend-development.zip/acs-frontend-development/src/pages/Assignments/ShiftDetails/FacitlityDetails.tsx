import LocationIcon from '@/assets/icons/Location.svg?react'
import PhoneIcon from '@/assets/icons/Phone.svg?react'
import UserIcon from '@/assets/icons/User_Circle.svg?react'
import { useAppSelector } from '@/hooks'

const FacilityDetails = () => {
  const assignmentDetails =
    useAppSelector((state) => state.assignments.assignmentDetails.data) || {}

  const getFacilityLocation = () => {
    return `${assignmentDetails.street_address}, ${assignmentDetails.city} - ${assignmentDetails.zip_code}, ${assignmentDetails.country}`
  }
  const generateMapUrl = () => {
    const encodedLocationName = encodeURIComponent(getFacilityLocation())
    return `https://www.google.com/maps/search/?api=1&query=${encodedLocationName}`
  }

  return (
    <>
      <p className="text-primary text-[20px] font-medium mt-[14px]">
        Facility Details
      </p>
      <div className="flex items-center mt-5">
        <LocationIcon className="size-[14px]" />
        <a
          className="text-13 text-green ml-2 mt-[2px]"
          href={generateMapUrl()}
          target="_blank"
        >
          {getFacilityLocation()}
        </a>
      </div>
      <p className="mt-3 font-semibold text-17 text-primary">
        {assignmentDetails.facility_name}
      </p>
      <div className="mt-2 w-full">
        <div className="flex items-center mt-2">
          <PhoneIcon className="fill-primary size-3" />
          <span className="ml-2 text-gray-700 text-15">
            {assignmentDetails.owner_phone}
          </span>
        </div>
        <div className="flex items-center mt-2">
          <UserIcon className="fill-primary size-4" />
          <span className="ml-2 text-gray-700 text-15">
            {assignmentDetails.owner_name}
          </span>
        </div>
      </div>
    </>
  )
}

export default FacilityDetails
