import { useState } from 'react'
import ModalWrapper from '@/components/ModalWrapper'
import FacilityDetails from './FacitlityDetails'
import AssignmentDetails from './AssignmentDetails'
import Loader from '@/components/Loader'
import BackwardIcon from '@/assets/icons/Arrow_Backward.svg?react'
import { useAppDispatch, useAppSelector } from '@/hooks'
import { toggleAssignmentDetailsModal } from '@/slices/assignmentsSlice'

const ShiftDetails = () => {
  const dispatch = useAppDispatch()
  const [isFacility, setIsFacility] = useState(false)
  const assignmentDetails = useAppSelector(
    (state) => state.assignments.assignmentDetails
  )

  const toggleModal = () => {
    setIsFacility(false)
    dispatch(toggleAssignmentDetailsModal())
  }

  const handleClickBack = () => {
    if (isFacility) {
      setIsFacility(false)
    } else {
      toggleModal()
    }
  }
  return assignmentDetails.isModalOpen ? (
    <ModalWrapper
      className="bg-transparent"
      isOpen={assignmentDetails.isModalOpen}
      onClose={toggleModal}
      closeOnOutsideClick={true}
      closeOnEsc={true}
    >
      <div className="relative flex flex-col items-start side-modal px-8 py-7 overflow-y-auto custom-scrollbar">
        <button className="flex items-center" onClick={handleClickBack}>
          <BackwardIcon className="fill-green size-2" />
          <span className="text-green ps-2 pt-[2px] text-13">Go Back</span>
        </button>
        {assignmentDetails.isLoading ? (
          <Loader center />
        ) : !assignmentDetails.data ? (
          <div className="absolute-center">Something went wrong</div>
        ) : isFacility ? (
          <FacilityDetails />
        ) : (
          <AssignmentDetails
            onFacilityDetailsClick={() => setIsFacility(true)}
          />
        )}
      </div>
    </ModalWrapper>
  ) : (
    <></>
  )
}

export default ShiftDetails
