export const DetailCard = ({
  title,
  value,
}: {
  title?: string
  value?: string
}) => {
  return (
    <div className="bg-gray-110 rounded-lg py-3 px-4 text-center">
      <p className="text-13 text-secondary">{title}</p>
      <p className="text-gray-900 text-15">{value}</p>
    </div>
  )
}
