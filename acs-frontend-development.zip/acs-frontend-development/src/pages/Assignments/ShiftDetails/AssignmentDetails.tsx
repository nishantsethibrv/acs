import ForwardIcon from '@/assets/icons/Arrow_Forward.svg?react'
import { useAppSelector } from '@/hooks'
import { formatTime } from '@/utils/dateTime'
import { DetailCard } from './DetailCard'

type AssignmentDetailsProps = {
  onFacilityDetailsClick?: () => void
}
const AssignmentDetails = ({
  onFacilityDetailsClick,
}: AssignmentDetailsProps) => {
  const assignmentDetails =
    useAppSelector((state) => state.assignments.assignmentDetails.data) || {}
  // education: Assignment
  // medical: Shift
  const isAssignment = assignmentDetails.facility_type === 'education'
  const assignmentType = isAssignment ? 'Assignment' : 'Shift'

  const getAssignmentDateTime = () => {
    let dateTime = ''
    if (assignmentDetails.start_date) {
      dateTime = new Date(assignmentDetails.start_date).formatDateD2M3Y4()
    }
    if (assignmentDetails.end_date) {
      dateTime += ` - ${new Date(assignmentDetails.end_date).formatDateD2M3Y4()}`
    }
    if (assignmentDetails.start_time) {
      dateTime += `, ${formatTime(assignmentDetails.start_time)}`
    }
    if (assignmentDetails.end_time) {
      dateTime += ` - ${formatTime(assignmentDetails.end_time)}`
    }
    return dateTime
  }

  const getAssignmentLocation = () => {
    return `${assignmentDetails.street_address}, ${assignmentDetails.city} - ${assignmentDetails.zip_code}, ${assignmentDetails.country}`
  }

  const generateMapUrl = () => {
    const encodedLocationName = encodeURIComponent(getAssignmentLocation())
    return `https://www.google.com/maps/search/?api=1&query=${encodedLocationName}`
  }

  return (
    <>
      <p className="text-primary text-[20px] font-medium mt-[14px]">
        {assignmentType} Details
      </p>
      <p className="text-13 text-green mt-5">{getAssignmentDateTime()}</p>
      <p className="mt-3 font-semibold text-17 text-primary">
        {assignmentDetails.shift_title}
      </p>
      <p className="text-gray-700 text-15 mt-2">{assignmentDetails.notes}</p>
      <div className="mt-6 w-full flex items-center border-b py-4">
        <div className="flex-grow">
          <p className="text-gray-550 text-13">Facility Details</p>
          <p className="text-gray-700 text-15 mt-1">
            {assignmentDetails.facility_name}
          </p>
        </div>
        <div>
          <button
            className="fab-circle size-7"
            onClick={onFacilityDetailsClick}
          >
            <ForwardIcon className="fill-white size-2" />
          </button>
        </div>
      </div>
      <div className="w-full flex items-center border-b py-4">
        <div className="flex-grow overflow-hidden mr-4">
          <p className="text-gray-550 text-13">{assignmentType} Location</p>
          <p className="text-gray-700 text-15 mt-1 overflow-ellipsis">
            {getAssignmentLocation()}
          </p>
        </div>
        <div>
          <a
            className="fab-circle size-7 cursor-pointer"
            href={generateMapUrl()}
            target="_blank"
          >
            <ForwardIcon className="fill-white size-2" />
          </a>
        </div>
      </div>
      <div className="mt-6 w-full">
        <p className="text-gray-550 text-13">Other Details</p>
        <div className="grid grid-cols-2 gap-3 mt-2">
          <DetailCard title="Unit/Department" value={assignmentDetails.unit} />
          <DetailCard title="Role" value={assignmentDetails.role} />
          <DetailCard
            title={`${assignmentType} Approver`}
            value={assignmentDetails.owner_name}
          />
          <DetailCard title="Days" value={assignmentDetails.shift_days} />
          <DetailCard
            title={`${assignmentType} Category`}
            value={assignmentDetails.shift_category}
          />
          <DetailCard
            title={`${assignmentType} Code`}
            value={assignmentDetails.job_code}
          />
          <DetailCard
            title={`${assignmentType} Type`}
            value={assignmentDetails.shift_type}
          />
          <DetailCard
            title="Certification"
            value={assignmentDetails.certifications}
          />
        </div>
      </div>
      <div className="mt-4 w-full">
        <p className="text-gray-550 text-13">Document Required</p>
        <div className="grid grid-cols-2 gap-3 mt-2">
          {assignmentDetails?.documents?.map((doc: Record<string, any>) => (
            <DetailCard
              key={doc.document_name}
              title={doc.document_name}
              value={doc.expiry_date}
            />
          ))}
        </div>
      </div>
    </>
  )
}

export default AssignmentDetails
