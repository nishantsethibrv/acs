import { useEffect, useMemo, useState } from 'react'
import ScheduleView from '@/components/ScheduleView'
import ForwardIcon from '@/assets/icons/Arrow_Forward.svg?react'
import BackwardIcon from '@/assets/icons/Arrow_Backward.svg?react'
import ShiftDetails from './ShiftDetails'
import Dropdown, { DropdownOption } from '@/components/Dropdown'
import { LoaderModal } from '@/components/Loader'
import { useAppDispatch, useAppSelector } from '@/hooks'
import {
  getAllAssignments,
  getAssignmentDetails,
  setNextMonth,
  setPrevMonth,
} from '@/slices/assignmentsSlice'
import { generateSchedule } from './utils'
import useWindowDimensions from '@/hooks/useWindowDimensions'

const tabOptions: DropdownOption[] = [
  { label: 'Assignments', value: 'assignments' },
  { label: 'Open', value: 'open' },
  { label: 'Pending', value: 'pending' },
  { label: 'Completed', value: 'completed' },
]

const Assignments = () => {
  const dispatch = useAppDispatch()
  const [selectedTab, setSelectedTab] = useState(tabOptions[0])
  const { width } = useWindowDimensions()
  const selectedMonthDate = useAppSelector(
    (state) => state.assignments.monthDate
  )
  const allAssignments = useAppSelector(
    (state) => state.assignments.allAssignments
  )
  const schedule = useMemo(
    () => generateSchedule(allAssignments.items, selectedMonthDate),
    [allAssignments.items, selectedMonthDate]
  )

  useEffect(() => {
    dispatch(getAllAssignments())
  }, [dispatch, selectedMonthDate])

  const handleNextMonthClick = () => {
    dispatch(setNextMonth())
  }
  const handlePrevMonthClick = () => {
    dispatch(setPrevMonth())
  }
  const handleTabSelect = (option: DropdownOption) => {
    setSelectedTab(option)
  }

  return (
    <>
      {allAssignments.isLoading && <LoaderModal isLoading={true} />}
      <div className="mt-9">
        <div className="flex ">
          <div className="flex flex-grow">
            {width > 1024 ? (
              <>
                <button className="btn-primary active mr-3">Assignments</button>
                <button className="btn-secondary mr-3">Open</button>
                <button className="btn-secondary mr-3">Pending</button>
                <button className="btn-secondary mr-3">Completed</button>
              </>
            ) : (
              <Dropdown
                options={tabOptions}
                selectedValue={selectedTab.value}
                onChange={handleTabSelect}
                itemClass="bg-transparent rounded-lg"
                contentClass="mr-3 mt-0 min-w-0 w-40 bg-white border rounded-xl"
              >
                <button className="btn-primary active mr-3 min-w-40">
                  {selectedTab.label}
                </button>
              </Dropdown>
            )}
          </div>

          <div className="flex">
            <button className="btn-primary px-3" onClick={handlePrevMonthClick}>
              <BackwardIcon className="size-3" />
            </button>
            <button className="btn-secondary px-4 mx-[10px] text-nowrap min-w-[140px]">
              {selectedMonthDate.getMonthYearString()}
            </button>
            <button className="btn-primary px-3" onClick={handleNextMonthClick}>
              <ForwardIcon className="size-3" />
            </button>
          </div>
        </div>
        <div className="mt-5">
          <ScheduleView
            year={selectedMonthDate.getFullYear()}
            month={selectedMonthDate.getMonth() + 1}
            schedule={schedule}
            onShiftClick={(shiftId) => {
              dispatch(getAssignmentDetails({ shiftId }))
            }}
          />
        </div>
      </div>
      <ShiftDetails />
    </>
  )
}

export default Assignments
